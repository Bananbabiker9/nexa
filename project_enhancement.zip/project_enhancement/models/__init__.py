from . import account_move
from . import project_project
from . import product_template
from . import mrp_pom
from . import mrp_production
from . import partner
from . import sale_order
from . import project_task
from . import stock_landed_cost


