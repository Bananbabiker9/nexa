
{
    'name': 'BOM Documents',
    'version': '14.0.1.0.0',
    'category': 'MRP',
    'author': 'DeeB',
    'depends': ['base', 'mrp'],
    'data': [
        'security/ir.model.access.csv',
        'views/employee_document_view.xml',
    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
